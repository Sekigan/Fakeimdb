package com.its.fakeimdb;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class Adapter extends FirestoreRecyclerAdapter<pelicula, Adapter.AdapterHolder> {


    public Adapter(@NonNull FirestoreRecyclerOptions<pelicula> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull AdapterHolder holder, int position, @NonNull pelicula model) {

        holder.textViewTitulo.setText(model.getTitulo());
        holder.textViewactores.setText(model.getActores());
        holder.textViewaño.setText(model.getAño());
        holder.textViewGenero.setText(model.getGenero());



    }


    @Override
    public AdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.lista,parent,false);

        return new AdapterHolder(view);
    }

    class AdapterHolder extends RecyclerView.ViewHolder{
        TextView textViewTitulo, textViewaño, textViewGenero, textViewactores;
        ImageView imageViewPoster;
        public AdapterHolder(View itemview){
            super(itemview);
            textViewTitulo=itemview.findViewById(R.id.textViewTitulo);
            textViewaño=itemview.findViewById(R.id.textViewaño);
            textViewactores=itemview.findViewById(R.id.textViewActores);
            textViewGenero=itemview.findViewById(R.id.textViewGenero);
            imageViewPoster=itemview.findViewById(R.id.imgPeli);

        }
    }
}
